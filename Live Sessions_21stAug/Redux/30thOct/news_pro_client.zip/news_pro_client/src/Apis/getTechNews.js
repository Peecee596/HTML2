import axios from 'axios'
let data = null
export const getTechNews = async()=>{

    await axios.get('https://newsapi.org/v2/top-headlines?country=ca&apiKey=398a122378434b528b1bb97dd9b712cb')
    .then(res=>{
        console.log(res)
        data = res.data.articles
    })
    .catch(err=>{
        console.log(err)
    })

    return data;


}