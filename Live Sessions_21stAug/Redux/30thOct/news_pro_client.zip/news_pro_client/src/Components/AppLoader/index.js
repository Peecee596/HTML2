import React, { useState, useEffect } from 'react'
import { useDispatch } from 'react-redux'
import { useHistory } from 'react-router'
import { setBusinessNews } from '../../actions/setBusinessNews'
import { setHeadlines } from '../../actions/setHeadlines'
import { setTechnologyNews } from '../../actions/setTechnologyNews'
import { getBusinessNews } from '../../Apis/getBusinessNews'
import { getHeadlines } from '../../Apis/getHeadlines'
import { getTechNews } from '../../Apis/getTechNews'

export default function AppLoader() {


    const [loading,setLoading] = useState(false)
    const dispatch = useDispatch()
    let history = useHistory()

    useEffect(()=>{

            const getData = async()=>{

                    const n1 = await getHeadlines()
                    console.log(n1)
                    setHeadlines(dispatch,n1)
                    

                    const n2 = await getTechNews()
                    console.log(n2)
                    setTechnologyNews(dispatch,n2)

                    const n3 = await getBusinessNews()
                    console.log(n3)
                    setBusinessNews(dispatch,n3)
                    setLoading(true)
           

            }
            getData()
            

    },[dispatch])



    const button = loading ? <button onClick={() => history.push({pathname:'/headlines'})}>Click here to Continue! </button>
                    : <button> Please Wait...</button> 
    return (
        <div>
            <h1> Please Wait...</h1>
            <h3> Your Application is Loading... </h3> 
                {button}
        </div>
    )
}
