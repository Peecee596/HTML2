import React from 'react'
import { Link } from 'react-router-dom'

export default function AppMenu() {
    return (
        <header id="header" class="fixed-top d-flex align-items-center">
          <div class="container">
            <div class="header-container d-flex align-items-center justify-content-between">
              <div class="logo">
                <h1 class="text-light"><Link to='/'><span>News Pro</span></Link></h1>
                <a href="index.html">
                    <img src="assets/img/logo.png" alt="" class="img-fluid" /></a>
              </div>
      
              <nav id="navbar" class="navbar">
                <ul>
                  <li><Link class="nav-link scrollto active" to="/headlines">Headlines</Link></li>
                  <li><Link class="nav-link scrollto" to="/technology">Technology</Link></li>
                  <li><Link class="nav-link scrollto" to="/business">Business</Link></li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
              </nav>
      
            </div>
          </div>
        </header>
    )
}
