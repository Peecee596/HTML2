import React from 'react'
import AppLoader from '../Components/AppLoader'

export default function LoadingContainer() {
    return (
        <React.Fragment>
            <AppLoader />
        </React.Fragment>
    )
}
