import axios from 'axios'
let data = null
export const getRandomUserData = async()=>{

            await axios.get('https://randomuser.me/api/')
            .then(res=>{
                console.log(res)
                data = res.data.results
            })
            .catch(err=>{

                console.log(err)
            })

    return data

}