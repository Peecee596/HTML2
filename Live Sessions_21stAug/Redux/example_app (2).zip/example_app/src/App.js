import React from 'react'
import { Switch,Route } from 'react-router'
import DashboardContainer from './Containers/DashboardContainer'
import ProfileContainer from './Containers/ProfileContainer'

export default function App() {
  return (
    <Switch>
      <Route exact path='/' component={DashboardContainer} />
      <Route exact path='/profile/view' component={ProfileContainer} />
    </Switch>
  )
}
