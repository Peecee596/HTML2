import { useEffect } from "react";
import { useDispatch } from 'react-redux'
import { Link } from "react-router-dom";
import { setUserData } from "../../actions/setUserData";
import { getRandomUserData } from "../../Apis/getRandomUserData";


function Dashboard() {

  const dispatch = useDispatch()

  useEffect(()=>{

          const getData = async()=>{

                const data = await getRandomUserData()
                console.log(data)
                setUserData(dispatch,data)
              
          }
          getData()

  },[dispatch])



  return (
    <div>
      <h1> Fetching User Details </h1>
      <h3> Profile info Fetched Successfully! </h3>
        <Link to='/profile/view'> 
            View Profile 
        </Link>
    </div>
  );
}

export default Dashboard;
