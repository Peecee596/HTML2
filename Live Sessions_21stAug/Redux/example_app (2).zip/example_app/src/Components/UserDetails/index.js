import React from 'react'
import { useHistory } from 'react-router'
import { useSelector } from 'react-redux'
import { css } from 'glamor'

const goBackStyles = css({
        textDecoration:`underline`,
        color:`red`,
        cursor:`pointer`

})
export default function UserDetails() {


    const data = useSelector((state)=> state.login.user_info)
    let history = useHistory()
    return (
        <div>
            <h3> {data[0].name.first} {' '} {data[0].name.last} </h3>
            <img src={data[0].picture.large} alt='' />
            <h4>{data[0].email} </h4>
            <h4> {data[0].gender}</h4>
            <h4>{data[0].location.city},{data[0].location.country}</h4>

            <span onClick={()=> history.goBack() } {...goBackStyles}> Go Back </span>
        </div>
    )
}
