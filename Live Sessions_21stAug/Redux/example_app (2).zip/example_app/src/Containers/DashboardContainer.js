import React from 'react'
import Dashboard from '../Components/Dashboard'

export default function DashboardContainer() {
    return (
        <React.Fragment>
            <Dashboard />
        </React.Fragment>
    )
}
