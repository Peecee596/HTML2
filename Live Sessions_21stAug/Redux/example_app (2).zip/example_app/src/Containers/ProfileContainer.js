import React from 'react'
import UserDetails from '../Components/UserDetails'

export default function ProfileContainer() {
    return (
        <React.Fragment>
            <UserDetails />
        </React.Fragment>
    )
}
