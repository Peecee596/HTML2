export const LOGIN_USER = 'LOGIN_USER'
export const TOGGLE_MENU = 'TOGGLE_MENU'
export const LOGOUT_USER = 'LOGOUT_USER'
export const ADD_TODOS = 'ADD_TODOS'