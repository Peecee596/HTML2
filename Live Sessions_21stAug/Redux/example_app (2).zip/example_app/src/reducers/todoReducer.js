import { ADD_TODOS } from "../actions/types";

const initialState = {
        todos: []
}

const todoReducer = (state = initialState,action) =>{

     const newState = {...state}


     switch(action.type){

            case ADD_TODOS:
                newState.todos.push(action.payload)

            break;

            default:
                return newState;
     }
     return newState;


}

export default todoReducer;