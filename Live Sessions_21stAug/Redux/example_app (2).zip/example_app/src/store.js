import { createStore , combineReducers , applyMiddleware, compose } from 'redux'
import loginReducer from './reducers/loginReducer'
import todoReducer from './reducers/todoReducer'
import { composeWithDevTools } from 'redux-devtools-extension';


const allReducers = combineReducers({
    login: loginReducer,
    todos:todoReducer
})

const store = createStore(
        allReducers,
        compose(
            applyMiddleware(),
            composeWithDevTools()
        )
)

console.log(store.getState())

export default store;


