import React from 'react'
import './App.css';
import { Switch, Route } from 'react-router-dom'
import DashboardContainer from './Containers/DashboardContainer';
import MainPageContainer from './Containers/MainPageContainer';
import Page404 from './Components/Page404';
import BusinessNewsContainer from './Containers/BusinessNewsContainer';
import TechNewsContainer from './Containers/TechNewsContainer'
import IPLTeamsContainer from './Containers/IPLTeamsContainer';
import TeamMumbaiContainer from './Containers/TeamMumbaiContainer';
import PlayerDetailsContainer from './Containers/PlayerDetailsContainer';
import TeamDetailsContainer from './Containers/TeamDetailsContainer';

function App() {
  return (
      <Switch>
          <Route exact path='/' component={MainPageContainer} /> 
          <Route exact path='/dashboard' component={DashboardContainer} />
          <Route exact path='/news/business' component={BusinessNewsContainer} />
          <Route exact path='/news/tech' component={TechNewsContainer} />
          <Route exact path='/ipl-teams-2021' component={IPLTeamsContainer} />
          <Route exact path='/team-details' component={TeamDetailsContainer} />
          <Route exact path='/player/:id/:name' component={PlayerDetailsContainer} />
          <Route path='*' component={Page404} />
      </Switch>
  );
}

export default App;
