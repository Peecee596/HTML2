import React from 'react'

export default function HomePageContent() {
    return (
        <div>
             <h1> I am a Home Page! </h1>
        </div>
    )
}
