import React from 'react'

export default function PlayerDetails(props) {
    return (
        <div>
            <h3> Your Player Details </h3>
            <h4> Player ID: {props.data.player_id} </h4> 
            <h4> Player Name: {props.data.player_name} </h4>
        </div>
    )
}
