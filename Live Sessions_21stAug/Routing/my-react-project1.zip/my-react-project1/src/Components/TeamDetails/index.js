import React from 'react'
import { useHistory } from 'react-router-dom'
export default function TeamDetails(props) {

    let history = useHistory()

    const goBack = ()=>{

        // Single Page Application routing
        // Page will not refresh 
       // history.goBack()

       window.location.replace('/ipl-teams-2021')
        

    }
    
    console.log(props)
    return (
        <div>
        <h3> Team: {props.data.team_name} </h3>
            <img 
                src={props.data.logo}
                alt=""
                width={250}
                height={250}
            />
        <h3> Owner: {props.data.owner} </h3>
        <h4> Head Coach: {props.data.head_coach} </h4>
        <h4> Bowling Coach: {props.data.bowling_coach} </h4>

        <button onClick={() => goBack()}> Go Back</button>
    </div>
    )
}
