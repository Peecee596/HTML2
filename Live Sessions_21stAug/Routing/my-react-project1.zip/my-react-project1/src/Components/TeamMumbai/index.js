import React from 'react'

export default function TeamMumbai(props) {

    console.log(props)
    return (
        <div>
            <h3> Team: Mumbai Indians</h3>
            <h3> Owner: {props.data.owner} </h3>
            <h4> Head Coach: {props.data.head_coach} </h4>
            <h4> Bowling Coach: {props.data.bowling_coach} </h4>
        </div>
    )
}
