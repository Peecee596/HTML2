import React from 'react'
import IPLTeams from '../Components/IPLTeams'
import MainPage from '../Components/MainPage'

export default function IPLTeamsContainer() {
    return (
        <React.Fragment>
            <MainPage />
            <IPLTeams />
        </React.Fragment>
    )
}
