import React from 'react'
import MainPage from '../Components/MainPage'
import PlayerDetails from '../Components/PlayerDetails'

export default function PlayerDetailsContainer(props) {

    console.log(props)
    const data = {
            player_id: props.match.params.id,
            player_name: props.match.params.name

    }
    return (
        <React.Fragment>
            <MainPage />
            <PlayerDetails data={data} />
        </React.Fragment>
    )
}
