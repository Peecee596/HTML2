import React from 'react'
import MainPage from '../Components/MainPage'
import TeamDetails from '../Components/TeamDetails'

export default function TeamDetailsContainer(props) {

    console.log(props)
    const data = {
            team_name: props.location.props.team_name,
            owner: props.location.props.owner,
            head_coach: props.location.props.head_coach,
            bowling_coach: props.location.props.bowling_coach,
            logo:props.location.props.logo
    }
    return (
        <React.Fragment>
            <MainPage />
            <TeamDetails data={data} />
        </React.Fragment>
    )
}
