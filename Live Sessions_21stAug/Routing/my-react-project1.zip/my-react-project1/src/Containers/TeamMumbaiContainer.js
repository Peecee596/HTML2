import React from 'react'
import MainPage from '../Components/MainPage'
import TeamMumbai from '../Components/TeamMumbai'

export default function TeamMumbaiContainer(props) {

    console.log(props)
    const data = {
            owner: props.location.props.owner,
            head_coach: props.location.props.head_coach,
            bowling_coach: props.location.props.bowling_coach
    }
    return (
        <React.Fragment>
            <MainPage />
            <TeamMumbai data={data} />
        </React.Fragment>
    )
}
