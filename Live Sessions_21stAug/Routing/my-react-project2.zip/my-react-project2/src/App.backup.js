import countries from './countries'
import './App.css'
function App() {

  console.log(countries)
  return (
      <div>
        <h1> Welcome to React App</h1>
        {countries.map((item,index)=>(

           <div class="wrapper" key={index}>
              <h3> {item.country_name}</h3>
                <img 
                    src={item.country_flag} 
                    alt="" 
                    width={250} 
                    height={250}
                    
                />
            </div>


        ))}
           


        

      </div>
      
  );
}

export default App;


// <div class="wrapper">
// <h3> {item.country_name}</h3>
// <img src={item.country_flag} width={250} height={250}/>
// </div>
