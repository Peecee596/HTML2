export const countries = [
    {
        "country_name":"India",
        "country_flag":"https://images.unsplash.com/photo-1597058712635-3182d1eacc1e?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1374&q=80",
    },
    {
        "country_name":"UK",
        "country_flag":"https://images.unsplash.com/photo-1590407499464-be68a7d8ec88?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1469&q=80",
    },
    {
        "country_name":"Canada",
        "country_flag":"https://images.unsplash.com/photo-1590197794698-1f4e1ac3d496?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1374&q=80",
    },
    {
        "country_name":"Germany",
        "country_flag":"https://images.unsplash.com/photo-1527866959252-deab85ef7d1b?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1470&q=80",
    },
    {
        "country_name":"China",
        "country_flag":"https://images.unsplash.com/photo-1601331179769-c89a0cca745a?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=686&q=80",
    },
    {
        "country_name":"Norway",
        "country_flag":"https://images.unsplash.com/photo-1599999268882-78ef52790bd6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1932&q=80",
    }
  
]