import React from 'react'
import { Link } from 'react-router-dom'
export default function Dashboard() {
    return (
        <div>
            <h1> I am a Dashbaord</h1>
            <Link to='/register'> Go to Register </Link>
        </div>
    )
}
