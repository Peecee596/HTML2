import React from 'react'
import './index.css'
export default function FormDetails(props) {

    console.log(props)
    const name = props.data.name
    const email = props.data.email
    const contact = props.data.contact
    
    return (
        <div class="details">
            <h1> Your Registration is Successful! </h1>
            <h3>You entered the following details:</h3> 
            <ul>
                <li>{name}</li> 
                <li>{email}</li> 
                <li>{contact}</li>
            </ul>
        </div>
    )
}
