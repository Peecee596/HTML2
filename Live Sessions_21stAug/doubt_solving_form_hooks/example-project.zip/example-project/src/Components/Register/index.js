import React,{ useState } from 'react'
import { useHistory } from 'react-router-dom'
import './index.css'

export default function Register() {

    const [first_name,setFirstName] = useState(null)
    const [last_name,setLastName] = useState(null)
    const [email,setEmail] = useState(null)
    const [contact,setContact] = useState(null)
    let history = useHistory()
    
    const handleInputChange = (e) =>{

        e.preventDefault()
        console.log(e)
        const target = e.target;
        const name = target.name
        const value = target.value
    
        if(name === 'first_name'){
            setFirstName(value)
        }
        if(name === 'last_name'){
            setLastName(value)
        }
        if(name === 'email'){
            setEmail(value)
        }
        if(name === 'contact'){
            setContact(value)
        }


    }
    const submitData = () => {

            const formData = {
                name: first_name + '' + last_name,
                email: email,
                contact: contact
            }

        history.push({
            pathname:'/success',
            props:formData
        })

       
      
        
           
          
    }

        console.log(first_name,last_name,email,contact)
        return (
            <section class="register">
            <form onSubmit={submitData}>
                <input
                    name="first_name"
                    onChangeCapture={handleInputChange}
                    type="text"
                    placeholder="Enter First Name"
                />
                <input 
                    name="last_name"
                    onChangeCapture={handleInputChange}
                    type="text"
                    placeholder="Enter Last Name"
                />
                <input 
                    name="email"
                    onChangeCapture={handleInputChange}
                    type="email"
                    placeholder="Enter Email"
                />
                <input 
                    name="contact"
                    onChangeCapture={handleInputChange}
                    type="number"
                    placeholder="Enter Contact no."
                />
               <button class="submit" type="submit">
                 Submit
                </button>
            </form>
            </section>
        )
    
}
