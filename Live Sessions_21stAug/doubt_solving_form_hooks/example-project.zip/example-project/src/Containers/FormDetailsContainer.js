import React from 'react'
import FormDetails from '../Components/FormDetails'

export default function FormDetailsContainer(props) {

    console.log(props)
    const data  = {
            name: props.location.props.name,
            email: props.location.props.email,
            contact: props.location.props.contact

    }


    return (
        <React.Fragment>
            <FormDetails data={data} />
        </React.Fragment>
    )
}
