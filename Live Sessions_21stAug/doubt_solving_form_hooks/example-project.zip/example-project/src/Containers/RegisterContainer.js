import React from 'react'
import Register from '../Components/Register'

export default function RegisterContainer() {
    return (
        <React.Fragment>
            <Register />
        </React.Fragment>
    )
}
