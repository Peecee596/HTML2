import React from 'react'
import { Switch, Route } from 'react-router-dom'
import Dashboard from './Components/Dashboard'
import FormDetailsContainer from './Containers/FormDetailsContainer'
import RegisterContainer from './Containers/RegisterContainer'
export default function Router() {
    return (
        <Switch>
            <Route exact path='/' component={Dashboard} />
            <Route exact path='/register' component={RegisterContainer} />
            <Route exact path='/success' component={FormDetailsContainer} />
        </Switch>
    )
}
