import React,{ useState } from 'react'
import './index.css'

export default Register() {

    const [first_name,setFirstName] = useState(null)
    const [last_name,setLastName] = useState(null)
    const [email,setEmail] = useState(null)
    const [contact,setContact] = useState(null)
    
    handleInputChange = (e) =>{

        e.preventDefault()
        console.log(e)
        const target = e.target;
        const name = target.name
        const value = target.value
    
        if(name === 'first_name'){
            setFirstName(value)
        }
        if(name === 'last_name'){
            setLastName(value)
        }
        if(name === 'email'){
            setEmail(value)
        }
        if(name === 'contact'){
            setContact(value)
        }


    }
    submitData = () => {

            const formData = {
                name: first_name + '' + last_name,
                email: email,
                contact: contact
            }

            console.log(formData)
           
          
    }

        console.log(this.state)
        return (
            <section class="register">
            <form onSubmitCapture={this.submitData}>
                <input
                    name="first_name"
                    onChangeCapture={this.handleInputChange}
                    type="text"
                    placeholder="Enter First Name"
                />
                <input 
                    name="last_name"
                    onChangeCapture={this.handleInputChange}
                    type="text"
                    placeholder="Enter Last Name"
                />
                <input 
                    name="email"
                    onChangeCapture={this.handleInputChange}
                    type="email"
                    placeholder="Enter Email"
                />
                <input 
                    name="contact"
                    onChangeCapture={this.handleInputChange}
                    type="number"
                    placeholder="Enter Contact no."
                />
               <button class="submit" type="submit">
                 Submit
                </button>
            </form>
            </section>
        )
    
}
