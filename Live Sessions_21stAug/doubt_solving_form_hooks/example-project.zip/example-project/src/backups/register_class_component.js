import React, { Component } from 'react'
import './index.css'
import { Redirect } from 'react-router-dom'

export default class Register extends Component {


   

    constructor(props){

        super(props)
        this.state = {
                first_name:null,
                last_name:null,
                email:null,
                contact:null
            }
    }


    
    handleInputChange = (e) =>{

        e.preventDefault()
        console.log(e)
        const target = e.target;
        const name = target.name
        const value = target.value
    
        if(name === 'first_name'){
            this.setState({first_name: value})
        }
        if(name === 'last_name'){
            this.setState({last_name: value})
        }
        if(name === 'email'){
            this.setState({email: value})
        }
        if(name === 'contact'){
            this.setState({contact:value})
        }


    }
    submitData = () => {

            const formData = {
                name: this.state.first_name + '' + this.state.last_name,
                email: this.state.email,
                contact: this.state.contact
            }

            console.log(formData)
            return(
                <Redirect 
                        to={{
                            pathname:'/',
                            props:formData
                        }}
                />
            )
          
    }

    render() {

        console.log(this.state)
        return (
            <section class="register">
            <form onSubmitCapture={this.submitData}>
                <input
                    name="first_name"
                    onChangeCapture={this.handleInputChange}
                    type="text"
                    placeholder="Enter First Name"
                />
                <input 
                    name="last_name"
                    onChangeCapture={this.handleInputChange}
                    type="text"
                    placeholder="Enter Last Name"
                />
                <input 
                    name="email"
                    onChangeCapture={this.handleInputChange}
                    type="email"
                    placeholder="Enter Email"
                />
                <input 
                    name="contact"
                    onChangeCapture={this.handleInputChange}
                    type="number"
                    placeholder="Enter Contact no."
                />
               <button class="submit" type="submit">
                 Submit
                </button>
            </form>
            </section>
        )
    }
}
