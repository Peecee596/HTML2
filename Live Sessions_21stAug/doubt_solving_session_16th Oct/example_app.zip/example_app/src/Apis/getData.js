import axios from 'axios'
let data = null
export const getData = async()=>{

        await axios.get('http://localhost:3000/users')
        .then(res=>{

                console.log(res)
                data = res.data

        })
        .catch(err=>{
            console.log(err)
        })

        return data;
}