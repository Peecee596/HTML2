import axios from 'axios'
let data = null
export const saveUser = async(id,name)=>{

        await axios.post('http://localhost:3000/users',{id,name})
        .then(res=>{

                console.log(res)
                data = res.data

        })
        .catch(err=>{
            console.log(err)
        })

        return data;
}