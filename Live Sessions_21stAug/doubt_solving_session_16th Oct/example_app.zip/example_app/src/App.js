import { Switch, Route } from 'react-router-dom'
import CreateUsers from './Components/CreateUser';
import UsersListContainer from './Pages/UsersListContainer';
function App() {


  return (
    <Switch>
        <Route exact path='/' component={UsersListContainer} />
        <Route exact path='/create/user' component={CreateUsers} />
        
    </Switch>
  );
}

export default App;
