import { useState,useEffect} from 'react'
import { useForm } from 'react-hook-form'
import { css } from 'glamor'
import { toast, ToastContainer } from  'react-toastify'
import { saveUser } from '../../Apis/saveUser'
import { useHistory } from 'react-router'

const errorStyles = css({
    margin:`1px`,
    padding:`1px`,
    color:`red`
})
export default function CreateUsers() {

    const [id,setUserID] = useState(null)
    const [name,setName] = useState(null)
    const [loading,setLoading] = useState(null)
    const { register, handleSubmit, formState:{ errors} } = useForm()
    let history = useHistory()

    useEffect(()=>{

            const id = Math.floor((Math.random() * 100) + 1)
            setUserID(id) 

    },[])



    const handleInputChange = (e)=>{

        e.preventDefault()
        const target = e.target
        const name = target.name
        if(name === 'name')
        {
            setName(target.value)
        }
    }


    const submitData = async ()=>{

            console.log(id,name)
            setLoading(true)

            try{
                    const data = await saveUser(id,name)
                    console.log(data)
                    toast.success("User Added!", {
                        position: toast.POSITION.TOP_RIGHT
                      });

                      setTimeout(()=>{

                        history.push({
                            pathname:"/"
                        })

                      },2000)
                    
            }
            catch(e){
                console.log(e)
                setLoading(false)
                toast.error("Something went Wrong", {
                    position: toast.POSITION.TOP_RIGHT
                  });
            }

    }

    const button = loading ? <button> Processing...</button>
                    : <button type="submit"> Submit </button>

    return (
        <div>
            <h1> Create User </h1>
            <form onSubmit={handleSubmit(submitData)}>
                <input 
                    name="name"
                    type="text"
                    placeholder="Enter Name"
                    onChangeCapture={handleInputChange}
                    {...register('name',{required:true,pattern:/[A-Za-z]{3}/ })}
                />
                {errors.name && <span {...errorStyles}> Name is Required! </span> }
                {button}
                <ToastContainer autoClose={2000} />
            </form>
        </div>
    )
}
