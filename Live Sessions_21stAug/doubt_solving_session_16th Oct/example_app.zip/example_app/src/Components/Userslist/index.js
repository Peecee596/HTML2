import { useState,useEffect } from 'react';
import { getData } from '../../Apis/getData'
function Userslist() {

  const [users,setData] = useState(null)

    useEffect(()=>{

          const getUsers = async()=>{

                const data = await getData()
                console.log(data)
                setData(data)

          }
          getUsers()
        
    },[])



  return (
    <div>
        <h1> List of Users </h1>
      
            <div>
               <table>
                  <thead>
                        <tr>ID</tr>
                       <tr>Name</tr>
                  </thead>
                  <tbody>
                      {users !=null && users.length ? 
                          users.map((item,index)=>(
                                <tr key={index}>
                                    <td>{item.id}</td> 
                                    <td>{item.name}</td> 
                                </tr>
                          ))
                                    
                      : <span> No Users Found! </span>}
              </tbody>
                 </table> 
            </div>
      
      
     


    </div>
  );
}

export default Userslist;
