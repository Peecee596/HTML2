import React from 'react'
import AppMenu from '../Components/AppMenu'
import CreateUsers from '../Components/CreateUser'

export default function CreateUserContainer() {
    return (
        <React.Fragment>
            <AppMenu />
            <CreateUsers />
        </React.Fragment>
    )
}
