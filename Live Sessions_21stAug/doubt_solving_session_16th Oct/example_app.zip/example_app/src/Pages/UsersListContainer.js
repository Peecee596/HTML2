import React from 'react'
import AppMenu from '../Components/AppMenu'
import Userslist from '../Components/Userslist'

export default function UsersListContainer() {
    return (
        <React.Fragment>
            <AppMenu />
            <Userslist />
        </React.Fragment>
    )
}
