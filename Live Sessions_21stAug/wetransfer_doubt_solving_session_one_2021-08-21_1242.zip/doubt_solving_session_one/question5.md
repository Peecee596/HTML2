Question - Terminal Commands? 
---
  Creating a Folder
---
$ mkdir <folder-name>
---
  Go inside the Folder
---
$ cd <folder-name>
---
  Go Back
---
$ cd ..
---
  Clear Terminal
---
$ clear


